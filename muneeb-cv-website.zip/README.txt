# Muneeb CV Website (Static)
Files:
- index.html
- style.css
- script.js

- cv.pdf (optional — add your resume for the Download button)

How to run locally:
1) Open index.html in your browser, or
2) Use VS Code + Live Server.

How to deploy free (Netlify Drag & Drop):
1) Zip this folder
2) Go to https://app.netlify.com/drop
3) Drag the ZIP — done. Free link appears instantly.
