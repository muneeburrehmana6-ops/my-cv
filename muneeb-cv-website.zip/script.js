// Smooth scroll
document.querySelectorAll('.nav-links a').forEach(a=>{
  a.addEventListener('click', e=>{
    e.preventDefault();
    const id = a.getAttribute('href');
    document.querySelector(id)?.scrollIntoView({behavior:'smooth'});
    // Close mobile menu after click
    nav.classList.remove('show');
    hamburger.setAttribute('aria-expanded','false');
  });
});

// Theme toggle
const themeBtn = document.getElementById('theme-toggle');
const prefersLight = window.matchMedia('(prefers-color-scheme: light)').matches;
if (prefersLight) document.body.classList.add('light');
themeBtn.addEventListener('click', ()=>{
  document.body.classList.toggle('light');
  themeBtn.textContent = document.body.classList.contains('light') ? '☀️' : '🌙';
});

// Hamburger menu
const hamburger = document.getElementById('hamburger');
const nav = document.getElementById('nav-links');
hamburger.addEventListener('click', ()=>{
  const expanded = hamburger.getAttribute('aria-expanded') === 'true';
  hamburger.setAttribute('aria-expanded', String(!expanded));
  nav.classList.toggle('show');
});

// Reveal on scroll
const sections = document.querySelectorAll('.section');
const onScroll = ()=>{
  const trigger = window.innerHeight * 0.85;
  sections.forEach(sec=>{
    const rect = sec.getBoundingClientRect();
    if(rect.top < trigger) sec.classList.add('show');
  });
};
window.addEventListener('scroll', onScroll);
window.addEventListener('load', onScroll);

// Typing effect
const typingEl = document.getElementById('typing');
const roles = [
  'Frontend Developer',
  'UI/UX Enthusiast',
  'Problem Solver'
];
let r = 0, c = 0, typing = true;
function loop(){
  const text = roles[r];
  if (typing){
    if (c < text.length){
      typingEl.textContent += text[c++];
      return setTimeout(loop, 90);
    } else {
      typing = false;
      return setTimeout(loop, 1200);
    }
  } else {
    if (c > 0){
      typingEl.textContent = text.slice(0, --c);
      return setTimeout(loop, 40);
    } else {
      typing = true;
      r = (r + 1) % roles.length;
      return setTimeout(loop, 300);
    }
  }
}
loop();

// Contact form (demo)
document.getElementById('contactForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  alert('✅ Thank you! Your message has been sent.');
  e.target.reset();
});

// Year in footer
document.getElementById('year').textContent = new Date().getFullYear();
